from kubiya_sdk.tools import FileSpec

COMMON_ENV = [
]

COMMON_FILES = [
]

COMMON_SECRETS = [
    "GH_TOKEN", # Github Token (integration) - https://docs.kubiya.ai/integrations/github
]