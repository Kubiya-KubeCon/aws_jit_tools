from .tools import generate_iam_access_tools

# Generate tools when module is imported
generate_iam_access_tools() 